# Maison Claire : page de débarras (Seine-et-Marne)

Site statique, sans framework ni dépendance. Tout le dossier se dépose tel quel à la racine du domaine `https://maisonclaire-debarras.fr/`.

```
index.html          page complète (CSS, JS et JSON-LD intégrés)
logo.svg            logo, version claire (texte vectorisé, sans dépendance de police)
logo-dark.svg       logo, version sombre (fonds foncés)
favicon.svg
fonts/              Fraunces 600, Inter 400 et 600 (woff2, sous-ensemble latin)
img/                karim-*, camion-*, protection-*, piece-vide-* (WebP, 2 tailles chacune), og.jpg, apple-touch-icon.png
robots.txt  sitemap.xml  llms.txt
```

## 1. Déploiement

Le formulaire est prêt pour **Netlify** (offre gratuite au démarrage, formulaire avec pièces jointes inclus ; vérifiez les quotas en vigueur).

1. Netlify > Add new site > Deploy manually : glisser le dossier.
2. Domain management : ajouter `maisonclaire-debarras.fr` comme **domaine principal** (pas de bascule vers `www`), HTTPS activé.
3. Forms > le formulaire `devis` apparaît après le premier déploiement. Activer la notification par e-mail (ou Slack) vers le téléphone qui rappelle les clients.
4. Vérifier : `curl -I https://maisonclaire-debarras.fr/` doit répondre `200`, sans redirection. C'est l'URL finale des annonces.

Autre hébergeur : retirer `data-netlify` et `netlify-honeypot` de la balise `<form>`, mettre l'adresse de votre outil de formulaire dans `action`, et aligner `maxUploadMb` (ci-dessous) sur sa limite de pièces jointes. Le texte d'aide du champ fichiers indique « 8 Mo » : le modifier aussi.

## 2. Réglages (bloc `CONFIG`, en bas de `index.html`)

| Clé | Rôle |
|---|---|
| `gtmId` | ID Google Tag Manager (`GTM-XXXXXXX`). Vide = aucune bannière, aucun suivi. Renseigné = bannière de consentement, puis GTM chargé seulement après « Accepter ». |
| `trackingPhone` | Numéro de suivi d'appels, ex. `{display:'01 00 00 00 00', e164:'+33100000000'}`. Remplace le numéro **uniquement** pour les visiteurs venus d'une annonce (gclid présent). Le vrai numéro reste dans le HTML, le JSON-LD et la fiche Google. |
| `maxUploadMb` | Limite des photos / vidéos envoyées par le formulaire (8 par défaut). |

## 3. Google Ads

**URL finales (une page = une intention, canonique inchangée) :**
- `https://maisonclaire-debarras.fr/` : H1 « Débarras de maison en Seine-et-Marne »
- `https://maisonclaire-debarras.fr/?v=succession` : H1 « Débarras de maison après un décès en Seine-et-Marne »
- `https://maisonclaire-debarras.fr/?v=appartement` : H1 « Débarras d'appartement en Seine-et-Marne » (et « Vous filmez l'appartement » dans le sous-titre)

**Événements `dataLayer` :**

| Événement | Quand | Paramètres |
|---|---|---|
| `call_click` | clic sur un lien `tel:` | `link_location` (entete, heros, prix, pied, barre_mobile, erreur_formulaire) |
| `whatsapp_click` | clic sur un lien WhatsApp | `link_location` |
| `form_submit` | envoi **réussi** du formulaire | `file_count`, `variant` |
| `photo_upload` | choix de photos ou d'une vidéo | `file_count`, `file_types` |

Dans GTM : un déclencheur « Événement personnalisé » par événement, relié à une balise de conversion Google Ads, avec le « Conversion Linker ». Conversions principales conseillées : `form_submit` et `call_click` (un clic n'est pas un appel abouti : si possible, mesurer aussi les appels réels via le numéro de suivi).

**Champs cachés du formulaire :** `gclid`, `gbraid`, `wbraid`, `v`, `utm_source`, `utm_medium`, `utm_campaign`, `utm_term`, `utm_content`, `consentement_mesure` (oui / non). N'importez un gclid en conversion hors ligne que si `consentement_mesure = oui`.

## 4. Consentement

- Consent Mode v2 : `ad_storage`, `ad_user_data`, `ad_personalization`, `analytics_storage` à `denied` par défaut (en tête de page, avant tout script).
- Bannière : « Refuser » et « Accepter » de même taille et même style. Fermer ou faire défiler ne vaut pas accord. Choix conservé 6 mois, modifiable via « Pied de page > Cookies > Modifier mes choix ».
- Aucun script de suivi chargé avant le choix. Refus = rien n'est chargé et les cookies `_ga`, `_gcl` éventuels sont supprimés.
- Si vous ajoutez d'autres outils (pixel Meta, chat…), passez à une CMP complète (ex. tarteaucitron.js, gratuit) plutôt que d'étendre cette bannière.

## 5. Garanties G1 à G8

Texte officiel, repris mot pour mot dans la section « Le risque est pour nous, pas pour vous », dans la carte de prix (G2), dans la FAQ et dans `llms.txt`. Le héros en affiche 3 résumés courts, validés. Pour modifier une garantie, la changer **partout** : rechercher `data-g="G` dans `index.html`, puis la FAQ et `llms.txt`.

## 6. À remplacer avant mise en ligne

Toutes ces valeurs sont surlignées en jaune (`data-demo`). Après remplacement, supprimer l'attribut `data-demo` : la recherche `data-demo` dans `index.html` doit renvoyer 0 résultat. Aucune n'est dans le JSON-LD.

| Valeur d'exemple | Où |
|---|---|
| Prénom du responsable terrain « Julien » | Étape 2 |
| E-mail `contact@maisonclaire-debarras.fr` | Mentions légales, Confidentialité |
| Assureur et n° RC pro « MMA IARD, contrat n° 145 678 901 » | FAQ « Êtes-vous assurés ? », pied de page, mentions légales |
| Médiateur « CM2C, 49 rue de Ponthieu, 75008 Paris » | Pied de page, rubrique Médiateur |
| Mention TVA « TVA non applicable, article 293 B du CGI » | Pied de page, mentions légales |
| Adresse du siège « 12 rue de la République, 77100 Meaux » | Mentions légales |
| Date de mise à jour « 25 novembre 2026 » | Fin de la FAQ (texte **et** attribut `datetime`) ; reporter la date dans `sitemap.xml` |
| Forme juridique, directeur de la publication, hébergeur | Mentions légales (ajoutés car obligatoires) |

**Sections masquées** (`hidden`) : « Avant / après » et « Avis Google ». Ne retirer `hidden` qu'avec de vraies photos (accord écrit du client) et de vrais avis Google copiés mot pour mot. Ne jamais ajouter `AggregateRating` ni `Review` au JSON-LD.

## 7. Check-list de lancement

- [ ] Valeurs d'exemple remplacées, `data-demo` = 0 résultat
- [ ] Fiche Google : même nom, même numéro, zone de service = mêmes communes, adresse masquée
- [ ] Un vrai envoi de formulaire avec une photo, notification reçue sur le téléphone
- [ ] Liens Appeler et WhatsApp testés sur un vrai téléphone (Android et iPhone)
- [ ] GTM en mode Aperçu : consentement `denied` au chargement, aucune balise avant le choix, les 4 événements remontent
- [ ] `curl -I` sur les 3 URL finales : `200`, pas de redirection
- [ ] Search Console : domaine validé, `sitemap.xml` envoyé
- [ ] Lighthouse mobile relancé sur l'URL de production ; données terrain (CrUX / Search Console) à lire après environ 28 jours de trafic
- [ ] Si le texte change : mettre à jour la date « mises à jour le », `sitemap.xml` et `llms.txt` en même temps
- [ ] À faire valider par un juriste (je ne suis pas avocat) : G5 (annulation jusqu'à 48 h, à comparer au droit de rétractation de 14 jours d'un contrat conclu à distance), G3 (règle et plafond d'indemnisation, couverture par l'assurance), et la phrase « jamais plus de 20 % au-dessus du devis sans votre accord écrit » dans G2 (elle peut se lire comme « jusqu'à +20 % sans vous demander » ; or la modification unilatérale du prix par le professionnel figure parmi les clauses interdites de l'art. R212-1, 3° du Code de la consommation), le modèle de devis, le contrat de médiation, l'attestation RC pro
- [ ] G7 : vérifier que chaque filière (déchetterie, ressourcerie, association) délivre un bon de dépôt
- [ ] Visite obligatoire sous 48 h pour chaque maison : prévoir qui remplace le responsable terrain en cas de pic de demandes
- [ ] Obligations à vérifier pour l'activité : récépissé de déclaration de transport de déchets en préfecture (art. R541-50 du Code de l'environnement, selon les tonnages transportés) ; si vous revendez des objets, régime des revendeurs d'objets mobiliers (registre)
